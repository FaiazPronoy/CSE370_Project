<?php
echo '<style>
body { 
  margin: 0; 
  padding: 0; 
  font-family: Oswald, sans-serif; 
  display: flex; 
  justify-content: center; 
  align-items: center; 
  height: 100vh;
}
.institutes_list { 
  text-align: left; 
  font-size: 21px; /* You can adjust the size here */
  width: 80%; /* Adjust the width as needed */
  margin: auto;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  border: 1px solid #ddd;
  padding: 8px;
}
</style>';

?>
